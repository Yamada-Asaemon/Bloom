# Bloom (Kotlin / Jetpack Compose)

Трекер отказа от плохих привычек. Нативный перенос Bloom.html.

## Картинки
Замените заглушки своими файлами (с теми же именами):
- `app/src/main/res/drawable-nodpi/app_icon.png` — иконка приложения и картинка в круге
- `app/src/main/res/drawable-nodpi/empty.png` — картинка пустого экрана

## Сборка
Пуш в ветку `main` → GitHub → вкладка Actions → «Build APK» → внизу страницы запуска
в Artifacts скачать `Bloom-debug-apk`. Gradle wrapper не нужен: workflow ставит Gradle 8.9 сам.
